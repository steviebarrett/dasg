<?php

$loginHtml = <<<HTML
    <form method="post" action="index.php" class="admin-login-form">
        <input type="hidden" name="m" value="admin">
        <input type="hidden" name="a" value="login">
        <input type="hidden" name="csrf_token" value="{$_SESSION['csrf_token']}">
        <button type="submit" class="btn btn-link">Admin login</button>
    </form>
HTML;

$logoutHtml = <<<HTML
    <form method="post" action="index.php" class="admin-logout-form">
      <input type="hidden" name="m" value="admin">
      <input type="hidden" name="a" value="logout">
      <input type="hidden" name="csrf_token" value="{$_SESSION['csrf_token']}">
      <button type="submit" class="btn btn-link">Logout</button>
    </form>
HTML;

$adminHtml = (!empty($_SESSION["loggedIn"]))
	? "<li>{$logoutHtml}</li>"
	: "<li>{$loginHtml}</li>";
echo <<<HTML
			</div>  <!-- end row -->
			</div>  <!-- end mainBody -->
    </div>
	<footer>
		<div class='container py-4 mt-5'>
			<div class='row'>
				
				<div class='col-12'>
					<ul>
						<li><a href='?m=index'><span class='gaelic'>Dachaigh</span><br>Homepage</a></li>
						<li><a href='?m=about'><span class='gaelic'>Mu dheidhinn</span><br>About</a></li>
						<!-- <li><a href='?m=records&a=list'>Browse Index</a></li> -->
						<!-- <li><a href='?m=records&a=search'>Search Index</a></li> -->
						<!-- <li><a href='?m=faq'>User Guide</a></li> -->
						<li><a href='?m=gratitude'><span class='gaelic'>Taing</span><br>Acknowledgments</a></li>
						<li><a href='?m=team'><span class='gaelic'>An Sgioba</span><br>Project Team</a></li>
						<li><a href='?m=contact'><span class='gaelic'>Sgrìobh thugainn</span><br>Contact Us</a></li>
						{$adminHtml}
					</ul>
				</div>
			</div>
		</div>
	</footer>
</body>
</html>
HTML;
